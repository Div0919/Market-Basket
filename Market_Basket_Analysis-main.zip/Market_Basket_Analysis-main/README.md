# Market_Basket_Analysis
To find the association rules between the items using the Apriori Algorithm. Or in other words, you have to find out those items/itemset that customers bought together which helps the owner for store layout/marketing. And then show the relative Sales of the data in Tableau Dashboard 
